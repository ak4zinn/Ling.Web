# Formulário
Aprenda como criar um simples e elegante formulário com HTML e CSS
<br>
<img src="https://1.bp.blogspot.com/-iem9LTDllYY/YKlwoY0uYYI/AAAAAAAAApo/9UUjW80biw4Ca-c0WWDkVFqC14OGh-pOQCLcBGAsYHQ/s320/formulario-html-css.png">
<br>
Temos uma aula no YouTube: https://www.youtube.com/watch?v=VCsNIRXNsmY
